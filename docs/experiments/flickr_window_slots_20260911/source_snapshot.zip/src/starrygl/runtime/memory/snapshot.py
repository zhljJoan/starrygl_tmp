from __future__ import annotations

import torch

from starrygl.runtime.comm import Route, distributed
from starrygl.store.remote_fetch import submit_owner_request
from starrygl.store.snapshot_history import SnapshotHistory


def bind_snapshot_history(runtime, store, hot, *, window_size: int = 1) -> None:
    """Bind temporal storage and one fixed cold-boundary subscriber route."""
    manager = runtime.memory_manager
    device = manager.values.device
    slices = store.graph.snapshot_csc_view.get("slices", ())
    if not slices:
        raise ValueError("snapshot history requires prepared snapshot CSC views")
    if hot.numel() and not torch.isin(hot.cpu(), slices[0]["dst_nodes"]).all():
        raise ValueError("re-Prepare bounded_stale snapshots with snapshot_hot_compute")
    owned = (manager.row_map >= 0).nonzero(as_tuple=True)[0]
    nodes = torch.unique(torch.cat((owned, hot, *(row["src_nodes"].to(device) for row in slices))))
    runtime.snapshot_history = SnapshotHistory(nodes, store.graph.num_nodes, window_size, manager.values.shape[-1])
    runtime.snapshot_version = 0
    runtime.snapshot_send_nodes = nodes.new_empty(0)
    runtime.snapshot_recv_nodes = nodes.new_empty(0)
    runtime.snapshot_route = None
    if distributed():
        remote = nodes[(manager.row_map[nodes] < 0) & ~torch.isin(nodes, hot)]
        request = submit_owner_request(remote, manager.node_dist_index, scheduler=runtime.comm,
                                       name="snapshot_boundary_subscribers")
        runtime.snapshot_send_nodes = request.recv_nodes
        runtime.snapshot_recv_nodes = remote[request.order]
        runtime.snapshot_route = Route(tuple(request.recv_counts.tolist()), tuple(request.send_counts.tolist()))
    runtime.skip_remote_non_hot_owner_commit = True


def hydrate_snapshot_history(batch, runtime) -> None:
    history = runtime.snapshot_history
    blocks = tuple(window[-1] for window in batch.iter_blocks())
    if len(blocks) > history.window_size:
        raise ValueError("Batch exceeds the configured snapshot history window_size")
    history.advance(int(blocks[0].cache["snapshot_id"]))
    packets = tuple(history.read(block.src_nodes, int(block.cache["snapshot_id"])) for block in blocks)
    last = packets[-1]
    ids = blocks[-1].src_nodes
    state = dict(batch.state)
    state.update({
        "neighbor_recurrent_snapshots": packets,
        "neighbor_recurrent": last[:, :history.dim],
        "neighbor_recurrent_ts": last[:, -1],
        "neighbor_recurrent_node_ids": ids,
        "neighbor_recurrent_shared_mask": runtime.memory_manager.row_map[ids] < 0,
    })
    batch.state = state


def commit_snapshot_history(runtime, delta) -> None:
    history = runtime.snapshot_history
    for nodes, version, values in delta.metadata.get("snapshot_states", ()):
        history.update(nodes, version, values)
        runtime.snapshot_version = version


def launch_snapshot_push(runtime) -> None:
    route = runtime.snapshot_route
    if route is None:
        return
    # Keep at most two immutable in-flight packets. This may expose a wait when
    # the network cannot keep pace; it never changes collective launch order.
    if len(runtime.pending_snapshot_pushes) >= 2:
        _finish_snapshot_push(runtime, runtime.pending_snapshot_pushes.pop(0))
    values = runtime.snapshot_history.read(runtime.snapshot_send_nodes, runtime.snapshot_version)
    runtime.pending_snapshot_pushes.append(runtime.comm.launch_push(route, values, name="snapshot_boundary:owner"))


def finish_snapshot_pushes(runtime, *, ready_only: bool) -> None:
    waiting = []
    for handle in runtime.pending_snapshot_pushes:
        if not ready_only or handle.ready():
            _finish_snapshot_push(runtime, handle)
        else:
            waiting.append(handle)
    runtime.pending_snapshot_pushes = waiting


def _finish_snapshot_push(runtime, handle) -> None:
    packets = runtime.comm.finish_push(handle)
    runtime.snapshot_history.install(runtime.snapshot_recv_nodes, packets)


def install_shared_history(runtime, nodes, packets) -> None:
    # Hot replicas contribute cache candidates, never authoritative owner state.
    keep = runtime.memory_manager.row_map[nodes] < 0
    runtime.snapshot_history.install(nodes[keep], packets[keep])

# Sliding-window boundary cache

User decision (2026-09-11): retain cumulative increments, learnable gamma and
selective hot refresh; retain slots by sliding-window position instead of
allocating one slot for every dataset timestamp. Archived Flickr results still
refer to their archived implementation.

## Shared execution and storage boundary

The path traced before implementation is
`Prepare -> window row -> task slice -> graph accessor -> Batch -> state access ->
encode/scan -> loss/backward -> StateDelta -> owner commit/cache refresh`.
Event, Snapshot, node and edge work keep this runtime spine. This correction only
changes the existing history buffer's capacity, advancement and physical lookup.
No new loader, trainer, provider hierarchy or public cache-size setting.

## Window-relative slots

- Let W be the actual number of full snapshots plus the nonnegative chunk-decay
  prefix entries. Resolve it from the existing trainer window arguments when
  constructing state managers, including fit/evaluate/predict overrides.
- Allocate W circular output slots plus one predecessor slot, each covering
  locally needed nodes. A packet contains h, cumulative mean increment, count
  and producer version. Version zero denotes the explicit zero initial state;
  output of snapshot s records version s+1. Versions are metadata for causal
  lookup and delta-t, never indices into a dataset-sized allocation.
- For input snapshots `[1,2,3]`, retain E1/E2/E3 and a predecessor seed. When the
  window becomes `[2,3,4]`, promote the latest received observation <= E1 to the
  predecessor slot, retain E2/E3, and reuse the expired output slot for E4.
  Filtered nodes can keep an older predecessor and its cumulative statistics.
- Read the latest valid packet whose version <= the consumer snapshot id.
  Current-Batch immediately preceding local/hot outputs take priority over cache.
  Other rows use `h + sigmoid(gamma) * age * cumulative_mean_increment`.
- Normalize actual observed changes by elapsed snapshots. A recomputed node/time
  derives its statistics from earlier observations and replaces its output slot,
  so repeatedly scanning the overlap does not count the same observation twice.
  The predecessor carries the running count across window slides.
- Late packets at/before window entry can improve the predecessor only if newer
  than its existing observation. They cannot overwrite newer reused output slots.
  Packets beyond the active window are ignored. A backward window jump requires
  reset/replay; resetting also restores the initial predecessor.

## Ownership and communication

Prepared destinations include owner nodes and hot compute replicas. Loss,
metrics and authoritative state commits remain on node_master. Models return
StateDelta; runtime writes the history after backward.

At batch commit all computed temporal outputs are retained locally, while only
the final boundary is published: hot candidates pass the existing cosine/norm
filter and max_skip, then use all_gather; cold boundary owners use the fixed
all_to_all subscriber Route bound once at setup. State, increments, count and
version travel together. Empty hot participants keep the collective order.

Main-thread batch entry polls completed receives and materializes independent
Batch tensors. Feature prefetch remains enabled; Stage B does not mutate/read
this temporal cache concurrently. In-flight packets own their send buffers.
No per-snapshot hidden-state pull was introduced. DCRNN's reset-gate exchange and
wait remain per snapshot. max_skip bounds publication skips, not snapshot age.

The prepared `snapshot_hot_compute` declaration is unchanged by this retention
correction: artifacts from the immediately preceding hot-compute implementation
can be reused. Older owner-only artifacts still require re-Prepare. Sampled
neighbor execution retains its prior state path.

## Efficiency and validation

Torch masked max/gather/scatter replaces dataset-wide temporal lookup. Reuse the
existing SnapshotHistory, StateManager, committer, model compensation and filter.
No full-buffer roll, per-node Python loop or custom kernel. Storage is O(W*N*H)
and read selection O(W*requested nodes); native/predecessor-index optimization
remains unnecessary without a measured bottleneck.

For h=8 and all 2,302,925 Flickr nodes locally needed, W=2 uses about 0.47 GiB for
three packed slots plus validity, versus the previous 71-slot estimate of
11.12 GiB. These are allocation estimates excluding graphs, other stores and
transient gathers, not measured GPU peaks.

Checks cover repeated wraparound, preserved cumulative counts, filtered old
seeds, late/future arrivals, immutable gathered tensors, fixed allocation,
window overrides, and two-rank GPU sliding training beyond cache capacity.

```bash
python -m pytest -q tests
STARRYGL_TEST_NCCL=1 python -m torch.distributed.run --standalone --nproc_per_node=2 -m pytest -q tests/test_snapshot_history.py -k history_push
STARRYGL_TEST_NCCL=1 python -m torch.distributed.run --standalone --nproc_per_node=2 -m pytest -q tests/test_snapshot_history.py -k compile_prepare
python -m compileall -q src/starrygl
```

The window-sized correction passed 278 single-process tests (20 skipped).
Two-rank NCCL history exchange/backward and compile/Prepare/sliding-fit checks
passed for DCRNN and GConvGRU. Run the distributed groups separately with
`-k history_push` and `-k compile_prepare`: a combined invocation encountered an
NCCL bootstrap failure when recreating process groups; the isolated training
group passed. Compileall and the 500-line module limit also passed.
No new Flickr convergence or speedup is claimed.

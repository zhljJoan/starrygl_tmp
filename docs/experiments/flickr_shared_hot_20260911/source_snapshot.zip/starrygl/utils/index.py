from __future__ import annotations

import torch
from torch import Tensor


def compact_lookup_rows(source_ids: Tensor, query_ids: Tensor) -> Tensor:
    """Map query ids to source rows without allocating by the global id range."""

    query = query_ids.long()
    if int(query.numel()) == 0:
        return query.new_empty((0,))
    source = source_ids.to(device=query.device).long()
    if int(source.numel()) == 0:
        return torch.full_like(query, -1)

    order = torch.argsort(source, stable=True)
    sorted_ids = source.index_select(0, order)
    positions = torch.searchsorted(sorted_ids, query, right=True) - 1
    safe = positions.clamp(min=0, max=int(sorted_ids.numel()) - 1)
    found = (positions >= 0) & (sorted_ids.index_select(0, safe) == query)
    matched_rows = order.index_select(0, safe)
    return torch.where(found, matched_rows, torch.full_like(query, -1))


__all__ = ["compact_lookup_rows"]

from __future__ import annotations

from typing import Any, Mapping, Sequence

import torch

from starrygl.batch import SamplingPolicy
from starrygl.runtime.dataloader.materialize import AccessedWindow
from starrygl.runtime.sample import access_native_graphs, native_target_block
from starrygl.runtime.sample.blocks import sampled_edge_ids
from starrygl.store import StoreBundle
from starrygl.task import (
    SamplingRoot,
    attach_target_route,
    build_window_task_target,
    sampling_roots_from_target,
)
from starrygl.task.negative import snapshot_negative_dst_pool

from .cache import (
    _SnapshotEntry,
    _SnapshotGraphBlob,
    _evict_snapshot_blob_cache,
    _evict_snapshot_entry_cache,
    _materialize_snapshot_entries,
)
from .features import _attach_node_dist_index
from .rows import _apply_chunk_limit_to_snapshot_row, _chunk_order_tensor


def access_snapshot_window(
    store: StoreBundle,
    slices: Any,
    *,
    split: str,
    window_id: int,
    input_window: range | Sequence[int],
    chunk_limits: Sequence[int],
    sampling_policy: SamplingPolicy,
    native_sampler: Any | None = None,
    sampler_options: Mapping[str, Any] | None = None,
    num_negatives: int = 0,
    generator: object | None = None,
    entry_cache: dict[tuple[int, int], _SnapshotEntry] | None = None,
    blob_cache: dict[int, _SnapshotGraphBlob] | None = None,
) -> AccessedWindow:
    """Resolve native-sampled or prepared-CSC topology to one short tuple."""

    chunk_order = _chunk_order_tensor(sampler_options)
    rows = tuple(
        (slices[int(snapshot_id)], int(chunk_limit))
        for snapshot_id, chunk_limit in zip(input_window, chunk_limits)
        if 0 <= int(snapshot_id) < len(slices)
    )
    if not rows:
        raise ValueError(f"snapshot window {int(window_id)} has no prepared graph row")
    target_row = _apply_chunk_limit_to_snapshot_row(
        rows[-1][0],
        rows[-1][1],
        chunk_order=chunk_order,
    )
    options = sampler_options or {}
    negative_pool = None
    if store.labels.task_kind == "edge":
        negative_pool = snapshot_negative_dst_pool(
            local_dst_ids=target_row["dst_nodes"].long(),
            global_dst_ids=_snapshot_global_dst_pool(store),
            split=split,
            options=options,
        )
    target = build_window_task_target(
        store.labels,
        int(window_id),
        target_ts=_snapshot_target_ts(target_row, 1),
        negative_pool=negative_pool,
        num_negatives=int(num_negatives),
        generator=generator if isinstance(generator, torch.Generator) else None,
    )

    if sampling_policy == "neighbor":
        if native_sampler is None:
            raise ValueError("neighbor sampling requires an initialized native sampler")
        root = sampling_roots_from_target(target)
        roots = tuple(
            SamplingRoot(
                node_ids=root.node_ids,
                ts=_snapshot_target_ts(row, int(root.node_ids.numel())),
                groups=root.groups,
            )
            for row, _ in rows
        )
        blocks, feature_node_ids, edge_ids = access_native_graphs(native_sampler, roots)
        for (row, _), window in zip(rows, blocks):
            for block in window:
                block.cache.setdefault("snapshot_id", int(row.get("snapshot_id", 0)))
                _attach_node_dist_index(block, store)
    else:
        options = dict(options)
        options["defer_feature_launch"] = True
        options.pop("_materialize_device", None)
        entries = _materialize_snapshot_entries(
            store,
            rows,
            chunk_order=chunk_order,
            comm=None,
            options=options,
            entry_cache=entry_cache,
            blob_cache=blob_cache,
        )
        blocks = tuple((entry.graph,) for entry in entries)
        feature_node_ids = tuple(entry.graph.src_nodes.long() for entry in entries)
        edge_ids = tuple(sampled_edge_ids(window) for window in blocks)
        minimum = int(rows[0][0].get("snapshot_id", window_id))
        if entry_cache is not None:
            _evict_snapshot_entry_cache(entry_cache, minimum)
        if blob_cache is not None:
            _evict_snapshot_blob_cache(blob_cache, minimum)

    graph = native_target_block(blocks[-1])
    target = attach_target_route(graph, target, collect_remote_endpoints=True)
    return int(window_id), {"task": target}, blocks, feature_node_ids, edge_ids


def _snapshot_target_ts(row: Mapping[str, Any], count: int) -> torch.Tensor | None:
    ts = row.get("ts")
    if ts is None or int(count) == 0:
        return None
    if int(ts.numel()) == 0:
        return ts.new_empty((0,))
    return (torch.floor(ts.max()).long() + 1).reshape(1).expand(int(count)).clone()


def _snapshot_global_dst_pool(store: StoreBundle) -> torch.Tensor:
    cached = store.graph.runtime_cache.get("snapshot_global_dst_pool")
    if isinstance(cached, torch.Tensor):
        return cached
    if store.graph.num_nodes > 0:
        pool = torch.arange(int(store.graph.num_nodes), dtype=torch.long)
    elif store.features.node_ids is not None and int(store.features.node_ids.numel()) > 0:
        pool = store.features.node_ids.long().cpu()
    else:
        values = [
            row["dst_nodes"].long().cpu()
            for row in store.graph.snapshot_csc_view.get("slices", [])
            if "dst_nodes" in row and int(row["dst_nodes"].numel()) > 0
        ]
        pool = (
            torch.unique(torch.cat(values), sorted=True)
            if values
            else torch.empty(0, dtype=torch.long)
        )
    store.graph.runtime_cache["snapshot_global_dst_pool"] = pool
    return pool


__all__ = ["access_snapshot_window"]

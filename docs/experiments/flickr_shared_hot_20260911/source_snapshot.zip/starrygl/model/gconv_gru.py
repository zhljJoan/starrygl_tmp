from __future__ import annotations

from dataclasses import replace

import torch
from torch import Tensor, nn

from starrygl.batch import Batch
from starrygl.utils.index import compact_lookup_rows
from starrygl.view import GraphBlock

from ._graph_ops import EdgeScore, edge_scores, is_edge_task, is_node_task, state_delta_values
from .base import ModelOutput, StarryModel, StateDelta
from .graph_conv import GCNConv
from .layers import StateIncrementEstimator


class GConvGRUCell(nn.Module):
    """Graph convolution over neighbor state followed by a local GRU update."""

    reads_neighbor_state = True
    state_kind = "neighbor_recurrent"
    state_key = "neighbor_recurrent"

    def __init__(self, hidden_dim: int) -> None:
        super().__init__()
        self.graph_conv = GCNConv(2 * int(hidden_dim), int(hidden_dim))
        self.gru = nn.GRUCell(int(hidden_dim), int(hidden_dim))

    def materialize(self, blocks, src):
        block = blocks[-1]
        message = self.graph_conv(block, torch.cat((src["x"], src["h_prev"]), dim=-1))
        return {"message": message, "state_like": message}, block

    def local_forward(self, block: GraphBlock, src, dst):
        del block
        return self.gru(src["message"], dst["h_prev"])


class GConvGRUModel(StarryModel):
    def __init__(
        self,
        in_dim: int,
        hidden_dim: int,
        out_dim: int,
        *,
        node_output_dim: int | None = None,
        state_compensation: bool = False,
        compensation_num_rows: int = 1,
        gamma_init: float = 0.5,
    ) -> None:
        super().__init__()
        self.hidden_dim = int(hidden_dim)
        self.state_shapes = {"neighbor_recurrent": (self.hidden_dim,)}
        self.input = nn.Linear(int(in_dim), self.hidden_dim)
        self.cell = GConvGRUCell(self.hidden_dim)
        self.output = nn.Linear(self.hidden_dim, int(out_dim))
        self.node_head = nn.Linear(self.hidden_dim, int(node_output_dim)) if node_output_dim is not None else None
        self.edge_score = EdgeScore(self.hidden_dim)
        self.gamma = nn.Parameter(torch.tensor(float(gamma_init))) if state_compensation else None
        self.increment = (
            StateIncrementEstimator(max(1, int(compensation_num_rows)), self.hidden_dim)
            if state_compensation
            else None
        )

    @property
    def runtime_cell(self) -> GConvGRUCell:
        return self.cell

    @property
    def runtime_input_project(self):
        return self.input

    @property
    def runtime_persist_state(self) -> bool:
        return True

    def runtime_prepare_scan(self, batch: Batch):
        return self._compensated_batch(batch)

    def encode(self, batch: Batch) -> ModelOutput:
        from starrygl.runtime.snapshot.scan import encode_model

        return encode_model(self, batch)

    def runtime_output_from_scan(self, batch: Batch, scan) -> ModelOutput:
        embeddings = scan.embeddings
        logits = None
        window_logits = ()
        if is_node_task(batch):
            head = self.node_head if self.node_head is not None else self.output
            window_logits = tuple(head(value) for value in scan.window_embeddings)
            logits = window_logits[-1]
        aux = edge_scores(batch, scan.final_block, embeddings, self.edge_score) if is_edge_task(batch) else {}
        if window_logits:
            aux["window_logits"] = window_logits
        return ModelOutput(
            embeddings=embeddings,
            logits=logits,
            state_embeddings=scan.state_embeddings,
            aux=aux,
        )

    def state_update(self, batch: Batch, output: ModelOutput) -> StateDelta | None:
        if output.state_embeddings is None:
            return None
        self._update_increment(batch, output)
        block = tuple(batch.iter_blocks())[-1][-1]
        node_ids = block.dst_nodes.long()
        table_ids = batch.state.get("neighbor_recurrent_node_ids")
        if isinstance(table_ids, Tensor):
            rows = compact_lookup_rows(table_ids, node_ids.to(table_ids.device))
            state = output.state_embeddings.index_select(0, rows.to(output.state_embeddings.device)).detach()
        else:
            node_ids, state = state_delta_values(batch, output.state_embeddings)
        return StateDelta(
            kind="neighbor_recurrent",
            node_ids=node_ids,
            values=state,
            timestamps=_state_timestamps(batch, node_ids, state),
        )

    def clear_state_compensation(self) -> None:
        if self.increment is not None:
            self.increment.clear()

    def compensate_state(self, historical: Tensor, rows: Tensor) -> Tensor:
        return historical + torch.sigmoid(self.gamma) * self.increment.estimate(rows).to(historical)

    def _compensated_batch(self, batch: Batch) -> tuple[Batch, dict[str, Tensor]]:
        if self.increment is None or self.gamma is None:
            return batch, {}
        values = batch.state.get("neighbor_recurrent")
        if not isinstance(values, Tensor):
            return batch, {}
        compensated = values + self.gamma.to(device=values.device, dtype=values.dtype) * 0
        state = dict(batch.state)
        state["neighbor_recurrent"] = compensated
        model_batch = replace(batch, state=state)
        historical = batch.state.get("neighbor_recurrent_historical")
        mask = batch.state.get("neighbor_recurrent_shared_mask")
        rows = batch.state.get("neighbor_recurrent_shared_rows")
        if not all(isinstance(value, Tensor) for value in (historical, mask, rows)):
            return model_batch, {}
        historical = historical.to(device=values.device, dtype=values.dtype)
        mask = mask.to(device=values.device, dtype=torch.bool)
        rows = rows.to(device=values.device, dtype=torch.long)
        valid = mask & (rows >= 0)
        pos = valid.nonzero(as_tuple=True)[0]
        if not int(pos.numel()):
            return model_batch, {}
        shared_rows = rows.index_select(0, pos)
        predicted = self.compensate_state(historical.index_select(0, pos), shared_rows)
        compensated.index_copy_(0, pos, predicted)
        return model_batch, {
            "state_compensation_pos": pos,
            "state_compensation_rows": shared_rows,
            "state_compensation_historical": historical.index_select(0, pos).detach(),
        }

    def _update_increment(self, batch: Batch, output: ModelOutput) -> None:
        if self.increment is None or output.state_embeddings is None:
            return
        pos = output.aux.get("state_compensation_pos")
        rows = output.aux.get("state_compensation_rows")
        historical = output.aux.get("state_compensation_historical")
        node_ids = batch.state.get("neighbor_recurrent_node_ids")
        if not all(isinstance(value, Tensor) for value in (pos, rows, historical, node_ids)):
            return
        updated_nodes = torch.cat([window[-1].dst_nodes.long() for window in batch.iter_blocks()])
        state_nodes = node_ids.to(updated_nodes.device)
        keep = torch.isin(state_nodes.index_select(0, pos.to(updated_nodes.device)), updated_nodes)
        keep_pos = keep.nonzero(as_tuple=True)[0]
        if not int(keep_pos.numel()):
            return
        state_pos = pos.index_select(0, keep_pos.to(pos.device))
        change = output.state_embeddings.index_select(0, state_pos.to(output.state_embeddings.device)).detach()
        change = change - historical.index_select(0, keep_pos.to(historical.device)).to(change)
        self.increment.update(rows.index_select(0, keep_pos.to(rows.device)), change)


def _state_timestamps(batch: Batch, node_ids: Tensor, values: Tensor) -> Tensor | None:
    block = tuple(batch.iter_blocks())[-1][-1]
    if batch.mode == "snapshot" and "snapshot_id" in block.cache:
        return values.new_full((int(node_ids.numel()),), float(block.cache["snapshot_id"] + 1))
    target = batch.targets.get("task") if isinstance(batch.targets, dict) else None
    target_ids = getattr(target, "target_ids", None)
    target_ts = getattr(target, "target_ts", None)
    if isinstance(target_ids, Tensor) and isinstance(target_ts, Tensor):
        rows = compact_lookup_rows(target_ids.detach(), node_ids.detach())
        if not bool(torch.any(rows < 0).item()):
            return target_ts.detach().to(device=values.device, dtype=torch.float32).index_select(
                0, rows.to(device=values.device)
            )
    snapshot_id = getattr(target, "snapshot_id", None)
    return None if snapshot_id is None else values.new_full((int(node_ids.numel()),), float(snapshot_id))


__all__ = ["GConvGRUCell", "GConvGRUModel"]

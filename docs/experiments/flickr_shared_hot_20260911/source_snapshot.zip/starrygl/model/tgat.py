from __future__ import annotations

import torch
from torch import Tensor, nn
from starrygl.batch import Batch
from starrygl.utils.index import compact_lookup_rows

from ._graph_ops import EdgeScore, feature_for_window, first_block, is_edge_task, is_node_task
from .base import ModelOutput, StarryModel
from .layers import TemporalTransformerAttentionLayer
from .tgn import _edge_delta_t, _edge_features


class TGATModel(StarryModel):
    def __init__(
        self,
        in_dim: int,
        hidden_dim: int,
        out_dim: int,
        *,
        node_output_dim: int | None = None,
        edge_dim: int = 0,
        time_dim: int = 100,
        num_layers: int = 1,
        num_heads: int = 1,
        dropout: float = 0.1,
        att_dropout: float = 0.1,
    ) -> None:
        super().__init__()
        self.in_dim = int(in_dim)
        self.hidden_dim = int(hidden_dim)
        self.edge_dim = int(edge_dim)
        self.num_layers = max(1, int(num_layers))
        self.layers = nn.ModuleList(
            TemporalTransformerAttentionLayer(
                node_dim=self.in_dim if layer == 0 else self.hidden_dim,
                edge_dim=self.edge_dim,
                time_dim=int(time_dim),
                num_heads=int(num_heads),
                out_dim=self.hidden_dim,
                dropout=float(dropout),
                att_dropout=float(att_dropout),
            )
            for layer in range(self.num_layers)
        )
        node_dim = int(out_dim) if node_output_dim is None else int(node_output_dim)
        self.node_head = nn.Linear(self.hidden_dim, node_dim)
        self.edge_score = EdgeScore(self.hidden_dim)

    def encode(self, batch: Batch) -> ModelOutput:
        h: Tensor | None = None
        model_layer_edge_count = 0
        model_layer_block_count = 0
        for window_id, layer_blocks in enumerate(batch.iter_blocks()):
            base = feature_for_window(batch, "x", window_id).float()
            base_nodes = layer_blocks[0].src_nodes
            blocks = tuple(layer_blocks)
            if len(blocks) > 1 and not _mfg_chain_matches(blocks) and not _mfg_chain_matches(tuple(reversed(blocks))):
                h, h_nodes, _, edge_count, block_count = _encode_compact_frontiers(
                    blocks=blocks,
                    base=base,
                    base_nodes=base_nodes,
                    layers=self.layers,
                    edge_dim=self.edge_dim,
                )
                model_layer_edge_count += int(edge_count)
                model_layer_block_count += int(block_count)
            else:
                h = base
                h_nodes = base_nodes
                ordered_blocks = _attention_blocks(blocks)
                for layer_id, block in enumerate(ordered_blocks):
                    h = _align_to_src_nodes(h, h_nodes, block.src_nodes, base=base, base_nodes=base_nodes)
                    layer = self.layers[min(layer_id, self.num_layers - 1)]
                    edge_feat = _edge_features(batch, block, h.device, h.dtype, self.edge_dim)
                    edge_dt = _edge_delta_t(batch, block, h.device, h.dtype)
                    model_layer_edge_count += int(block.edge_ids.numel())
                    model_layer_block_count += 1
                    h = layer(block, h, edge_feat, edge_dt)
                    h_nodes = block.dst_nodes
        if h is None:
            block = first_block(batch)
            h = feature_for_window(batch, "x", 0).float()
            h_nodes = block.src_nodes
            for layer_id, layer in enumerate(self.layers):
                h = _align_to_src_nodes(h, h_nodes, block.src_nodes)
                edge_feat = _edge_features(batch, block, h.device, h.dtype, self.edge_dim)
                edge_dt = _edge_delta_t(batch, block, h.device, h.dtype)
                model_layer_edge_count += int(block.edge_ids.numel())
                model_layer_block_count += 1
                h = layer(block, h, edge_feat, edge_dt)
                h_nodes = block.dst_nodes
        logits = None
        if is_node_task(batch):
            logits = self.node_head(h) if self.node_head is not None else None
        aux = _edge_scores_from_nodes(batch, h_nodes, h, self.edge_score) if is_edge_task(batch) else {}
        aux["model_layer_edge_count"] = model_layer_edge_count
        aux["model_layer_block_count"] = model_layer_block_count
        return ModelOutput(
            embeddings=h,
            logits=logits,
            aux=aux,
        )


def _attention_blocks(blocks: tuple) -> tuple:
    if len(blocks) <= 1:
        return blocks
    if _mfg_chain_matches(blocks):
        return blocks
    reversed_blocks = tuple(reversed(blocks))
    if _mfg_chain_matches(reversed_blocks):
        return reversed_blocks
    return reversed_blocks


def _encode_compact_frontiers(
    *,
    blocks: tuple,
    base: Tensor,
    base_nodes: Tensor,
    layers: nn.ModuleList,
    edge_dim: int,
) -> tuple[Tensor, Tensor, object, int, int]:
    depth = min(len(blocks), len(layers))
    prev: list[tuple[Tensor, Tensor]] = []
    edge_count = 0
    block_count = 0
    for block in blocks[:depth]:
        src_h = _align_base_to_src(base, base_nodes, block.src_nodes, like=base)
        edge_feat = _edge_features_for_block(block, src_h, int(edge_dim))
        edge_dt = _edge_delta_for_block(block, src_h)
        edge_count += int(block.edge_ids.numel())
        block_count += 1
        out = layers[0](block, src_h, edge_feat, edge_dt)
        prev.append((block.dst_nodes, out))
    for layer_id in range(1, depth):
        current: list[tuple[Tensor, Tensor]] = []
        for block_id, block in enumerate(blocks[: depth - layer_id]):
            src_h = _merge_frontier_embeddings(block.src_nodes, prev[block_id], prev[block_id + 1])
            edge_feat = _edge_features_for_block(block, src_h, int(edge_dim))
            edge_dt = _edge_delta_for_block(block, src_h)
            edge_count += int(block.edge_ids.numel())
            block_count += 1
            out = layers[min(layer_id, len(layers) - 1)](block, src_h, edge_feat, edge_dt)
            current.append((block.dst_nodes, out))
        prev = current
    return prev[0][1], prev[0][0], blocks[0], edge_count, block_count


def _merge_frontier_embeddings(src_nodes: Tensor, *frontiers: tuple[Tensor, Tensor]) -> Tensor:
    values = [value for _, value in frontiers if int(value.numel()) > 0]
    if not values:
        raise RuntimeError("TGAT compact frontier has no embeddings to merge")
    like = values[0]
    out = like.new_zeros((int(src_nodes.numel()), int(like.shape[-1])))
    target = src_nodes.to(device=like.device).long()
    if int(target.numel()) == 0:
        return out
    for nodes, value in frontiers:
        if int(nodes.numel()) == 0:
            continue
        source = nodes.to(device=like.device).long()
        rows = compact_lookup_rows(source, target)
        valid = rows >= 0
        if bool(torch.any(valid).item()):
            keep = valid.nonzero(as_tuple=True)[0]
            out.index_copy_(0, keep, value.to(device=like.device).index_select(0, rows.index_select(0, keep)))
    return out


def _edge_features_for_block(block, h: Tensor, edge_dim: int) -> Tensor:
    value = block.edata.get("edge_feat")
    if value is None:
        value = block.edata.get("edge")
    if value is None:
        if int(edge_dim) == 0 or int(block.num_edges) == 0:
            return h.new_empty((int(block.num_edges), int(edge_dim)))
        raise RuntimeError(
            "edge_dim > 0 but TGAT block edge features are missing. "
            "Expected block.edata['edge_feat'] from sampled edge feature materialization."
        )
    value = value.to(device=h.device, dtype=h.dtype).reshape(int(block.num_edges), -1)
    if int(value.shape[1]) == int(edge_dim):
        return value
    if int(value.shape[1]) > int(edge_dim):
        return value[:, : int(edge_dim)]
    return torch.cat((value, h.new_zeros((int(value.shape[0]), int(edge_dim) - int(value.shape[1])))), dim=1)


def _edge_delta_for_block(block, h: Tensor) -> Tensor:
    value = block.edata.get("dt")
    if value is None:
        value = block.edata.get("delta_t")
    if value is None:
        return h.new_zeros((int(block.num_edges),))
    return value.to(device=h.device, dtype=h.dtype).reshape(-1)


def _edge_scores_from_nodes(batch: Batch, nodes: Tensor, embeddings: Tensor, scorer: EdgeScore) -> dict[str, Tensor]:
    tgt = batch.targets.get("task")
    if tgt is None or tgt.pos_src is None or tgt.pos_dst is None:
        return {}
    pos_src_rows = _rows_for_nodes(nodes, tgt.pos_src.to(device=embeddings.device), embeddings.device)
    pos_dst_rows = _rows_for_nodes(nodes, tgt.pos_dst.to(device=embeddings.device), embeddings.device)
    out = {
        "pos_score": scorer(embeddings.index_select(0, pos_src_rows), embeddings.index_select(0, pos_dst_rows)),
    }
    if tgt.neg_dst is not None:
        neg_src = tgt.neg_src if tgt.neg_src is not None else tgt.pos_src.repeat_interleave(max(1, int(tgt.neg_dst.numel()) // max(1, int(tgt.pos_src.numel()))))
        neg_src_rows = _rows_for_nodes(nodes, neg_src.to(device=embeddings.device), embeddings.device)
        neg_dst_rows = _rows_for_nodes(nodes, tgt.neg_dst.to(device=embeddings.device), embeddings.device)
        out["neg_score"] = scorer(embeddings.index_select(0, neg_src_rows), embeddings.index_select(0, neg_dst_rows))
    return out


def _rows_for_nodes(nodes: Tensor, query: Tensor, device: torch.device) -> Tensor:
    source = nodes.to(device=device).long()
    query = query.to(device=device).long()
    if int(source.numel()) == 0 or int(query.numel()) == 0:
        return torch.empty(int(query.numel()), dtype=torch.long, device=device)
    rows = compact_lookup_rows(source, query)
    if bool(torch.any(rows < 0).item()):
        missing = int((rows < 0).sum().item())
        raise RuntimeError(f"TGAT endpoint embeddings missing {missing} sampled root nodes")
    return rows


def _mfg_chain_matches(blocks: tuple) -> bool:
    return all(torch.equal(blocks[i].dst_nodes.long(), blocks[i + 1].src_nodes.long()) for i in range(len(blocks) - 1))


def _align_to_src_nodes(
    h: Tensor,
    h_nodes: Tensor,
    src_nodes: Tensor,
    *,
    base: Tensor | None = None,
    base_nodes: Tensor | None = None,
) -> Tensor:
    if torch.equal(h_nodes.to(device=src_nodes.device).long(), src_nodes.long()):
        return h
    from_nodes = h_nodes.to(device=h.device).long()
    to_nodes = src_nodes.to(device=h.device).long()
    if int(from_nodes.numel()) == 0 or int(to_nodes.numel()) == 0:
        return h.new_zeros((int(to_nodes.numel()), int(h.shape[-1])))
    rows = compact_lookup_rows(from_nodes, to_nodes)
    out = _align_base_to_src(base, base_nodes, src_nodes, like=h) if base is not None and base_nodes is not None else h.new_zeros((int(to_nodes.numel()), int(h.shape[-1])))
    valid = rows >= 0
    if bool(torch.any(valid).item()):
        keep = valid.nonzero(as_tuple=True)[0]
        out.index_copy_(0, keep, h.index_select(0, rows.index_select(0, keep)))
    return out


def _align_base_to_src(base: Tensor, base_nodes: Tensor, src_nodes: Tensor, *, like: Tensor) -> Tensor:
    if int(base.shape[-1]) != int(like.shape[-1]):
        return like.new_zeros((int(src_nodes.numel()), int(like.shape[-1])))
    nodes = base_nodes.to(device=like.device).long()
    target = src_nodes.to(device=like.device).long()
    if int(nodes.numel()) == 0 or int(target.numel()) == 0:
        return like.new_zeros((int(target.numel()), int(like.shape[-1])))
    rows = compact_lookup_rows(nodes, target)
    out = like.new_zeros((int(target.numel()), int(like.shape[-1])))
    valid = rows >= 0
    if bool(torch.any(valid).item()):
        keep = valid.nonzero(as_tuple=True)[0]
        out.index_copy_(0, keep, base.to(device=like.device, dtype=like.dtype).index_select(0, rows.index_select(0, keep)))
    return out


__all__ = ["TGATModel"]
